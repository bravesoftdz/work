VCLZip Native Delphi Zip/UnZip Component Beta! (version 0.01 Beta Sept 28, 1997)

Well, it's finally here!! I apologize to all those that have been patiently
awaiting the arrival of the VCLZip component. Hopefully you will find that 
the wait was worth it.  However, VCLZip is still not quite ready for 
registration just yet. I would like your help in beta testing the new VCLZip 
component in order to eliminate any remaining kinks. If you would like to take 
the beta for a test drive, please download the completely functional (while 
running within the Delphi IDE) component below. Let me know what you think. 
Most of all, let me know if you find any bugs, inconsistencies, or anything 
that is missing. Let me know if there are any problems with the installation 
process as well. Be as clear in your problem description as possible.

When you provide input, please give as much information as possible. Be sure 
to include the following information:

	1. Platform (Win95 or NT)
	2. Version of Delphi (2 or 3)
	3. System information (i.e.486/Pentium, memory)

Send all input to boylank@bigfoot.com

Currently Under Construction:

	- At this time, VCLZip is only compatible with WIN32 Delphi 2 and 3. 
	  Let me know if a 16 bit version for Delphi 1 is important to you. 
	  The VCLUnZip component does, however, support 16 bit Delphi 1.

	- The only feature missing from VCLZip at this time is the ability to 
	  create spanned zip files (it will read them however). This feature 
	  is being developed right now and will be available in a future 
	  version (soon). Registered users will receive that upgrade for fee!

	- The help file is a bit sparse. I believe all properties, methods, and 
	  events are documented, but I will be adding more examples and more 
	  complete descriptions as we go along. I will also keep a separate 
	  updated downloadable help file available on this web page and I also 
	  hope to include online help soon. 

VCLZip Description

VCLZip is a full featured zip/unzip component and is now in beta for Delphi 2 
and 3. Download the appropriate file below for everything needed to test the 
new VCLZip component. Features include:

	- Create zip files fully compatable with PKZip
	- Completely native Delphi VCL
	- Zip directly from streams to zip files
	- Unzip directly to streams from zip files
	- Create and read Zip and File Comments
	- Create Self Extracting Zip Files (16 bit and 32 bit distributable 
	  windows sfx stubs included)
	- Complete support for encrypted files (encrypts as it zips)
	- Plenty of events
	- Includes comprehensive Zip Utility with source as demo
	- Includes a context sensitive help file
	- Also receive a zip password recovery utility with registration
	- No Royalties!
	- Initial price of only $49.95!!!

VCLZip inherits from VCLUnZip, so for those applications that only need unzip 
capabilities (for instance installation programs), you only need to use the 
VCLUnZip component (which is ofcourse included with VCLZip) thereby decreasing 
your application's footprint.


Registration will get you:

	- All Source Code
	- Zip Password Recovery Utility
	- Notification of future patches and updates
	- Free point release upgrades

Currently Registered VCLUnZip users will be able to register VCLZip for only $20!!

Contact boylank@bigfoot.com for further information


