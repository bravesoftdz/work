DECLARE @Barcode varchar(15)
DECLARE @Image varchar(50)
DECLARE @Description varchar(100)
DECLARE @Model varchar(25)
DECLARE @IDModel int
DECLARE @MSRP money
DECLARE @VendorCode varchar(50)
DECLARE @Vendor varchar(50)
DECLARE @MinQty int
DECLARE @CaseQty int
DECLARE @Cost money
DECLARE @IDPessoa int
DECLARE @IDVendorModelCode int
DECLARE @VendorOrder int
DECLARE @IDGroup int
DECLARE @IDModelGroup int
DECLARE @IDModelSubGroup int
DECLARE @Department varchar(50)
DECLARE @Category varchar(100)
DECLARE @SubCategory varchar(100)
DECLARE @UPC varchar(20)

---------------------------------------------------------------
--Update 10 Digit to 12 Digit UPC's
---------------------------------------------------------------
DECLARE BarcodeUpdate_Cursor Cursor FOR
	SELECT
		IDBarcode
	FROM
		MainRetailDB..Barcode
	WHERE
		LEN(IDBarcode) = 10
OPEN BarcodeUpdate_Cursor

FETCH NEXT FROM BarcodeUpdate_Cursor INTO
	@Barcode

WHILE
@@FETCH_STATUS =  0
BEGIN
	SELECT 
		@UPC = UPC
	FROM
		MRCatalogDB..Products
	WHERE
		SUBSTRING(UPC, 2, 10) = @Barcode

	IF @UPC IS NOT NULL AND @UPC <> ''
	BEGIN
		IF NOT EXISTS (SELECT IDBarcode FROM MainRetailDB..Barcode WHERE IDBarcode = @UPC)
		UPDATE MainRetailDB..Barcode SET IDBarcode = @UPC WHERE IDBarcode = @Barcode
	END
	
	FETCH NEXT FROM BarcodeUpdate_Cursor INTO
		@Barcode
END

CLOSE BarcodeUpdate_Cursor
DEALLOCATE BarcodeUpdate_Cursor
