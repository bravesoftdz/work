UPDATE Barcode SET BarcodeOrder = 1

DECLARE @Count 		int
DECLARE @IDModel 	int
DECLARE @IDBarcode 	varchar(30)
DECLARE @Order 		int

DECLARE BarcodeOrder_Cursor CURSOR FOR
	SELECT
		IDModel,
		Count(IDModel)
	FROM
		Barcode
	GROUP BY
		IDModel
	HAVING
		Count(IDModel) > 1

OPEN BarcodeOrder_Cursor

FETCH NEXT FROM BarcodeOrder_Cursor INTO
	@IDModel,
	@Count

WHILE
@@FETCH_STATUS = 0
BEGIN
	DECLARE Update_Cursor Cursor FOR
		SELECT
			IDBarcode
		FROM
			Barcode
		WHERE
			IDModel = @IDModel
		ORDER BY
			Qty ASC
			--IDBarcode DESC
	OPEN Update_Cursor
	
	FETCH NEXT FROM Update_Cursor INTO
		@IDBarcode
	SET @Order = 0
	WHILE
	@@FETCH_STATUS = 0
	BEGIN
		SELECT @Order = @Order + 1
		UPDATE
			Barcode
		SET
			BarcodeOrder  = @Order
		WHERE
			IDBarcode = @IDBarcode
		
		FETCH NEXT FROM Update_Cursor INTO
			@IDBarcode
	END
	CLOSE Update_Cursor
	DEALLOCATE Update_Cursor


	FETCH NEXT FROM BarcodeOrder_Cursor INTO
		@IDModel,
		@Count
END
CLOSE BarcodeOrder_Cursor
DEALLOCATE BarcodeOrder_Cursor

