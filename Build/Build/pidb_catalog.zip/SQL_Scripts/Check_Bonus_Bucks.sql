SELECT RD.IDPreSaleCreated, RD.DiscountValue, RD.ValidFromDate, RD.ExpirationDate, 
RD.IDPreSaleUsed, I.InvoiceDate, I.IDCustomer, I.IDInvoice
FROM Sal_RebateDiscount RD JOIN Invoice I 
ON (RD.IDPreSaleCreated = I.IDPreSale)
WHERE IDPreSaleCreated = 100069036