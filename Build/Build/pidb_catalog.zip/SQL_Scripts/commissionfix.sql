DECLARE @msg varchar(500)
DECLARE @IDSaleItemCommission int
DECLARE @mrcmd varchar(50)

DECLARE Commission_Fix CURSOR FOR
SELECT
	MR_CMD
FROM
	MR_RowDeleted
WHERE
	MR_DATE > '4/16/07' AND MR_Table_Name = 'VendorModelCode'

OPEN Commission_Fix

FETCH NEXT FROM Commission_Fix INTO
	@mrcmd

SET @IDSaleItemCommission = (SELECT MAX(IDVendorModelCode) FROM VendorModelCode)

WHILE
@@FETCH_STATUS = 0
BEGIN
	--SET @IDSaleItemCommission = @IDSaleItemCommission + 1
	SET @msg = 'INSERT INTO VendorModelCode(IDVendorModelCode, IDPessoa, IDModel,VendorCode) VALUES ('
			+ convert(varchar, @mrcmd) + ')'

	PRINT @msg

FETCH NEXT FROM Commission_Fix INTO 
	@mrcmd

END

CLOSE Commission_Fix
DEALLOCATE Commission_Fix

--SELECT @msg = 'UPDATE Sis_CodigoIncremental SET UltimoCodigo = (SELECT Max(IDVendorModelCode) FROM VendorModelCode) WHERE Tabela = ''SaleItemCommission.IDSaleItemCommission'''
--PRINT @msg