use MainRetailDB

DECLARE @IDGroup int
DECLARE @IDModelGroup int
DECLARE @IDModelSubGroup int
DECLARE @GroupName varchar(50)
DECLARE @ModelGroupName varchar(50)
DECLARE @ModelSubGroupName varchar(50)


----------------------------------------------------------------
--Insert tabgroups
----------------------------------------------------------------
PRINT 'Start Update TabGroups.'
DECLARE Group_Cursor Cursor FOR
	SELECT DISTINCT
		Department
	FROM
		MRCatalogDB..Products p

OPEN Group_Cursor

FETCH NEXT FROM Group_Cursor INTO
	@GroupName
WHILE
@@FETCH_STATUS=0
BEGIN
	print @GroupName
	IF NOT EXISTS(
		SELECT IDGroup FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	BEGIN
		EXEC sp_Sis_GetNextCode'TabGroup.IDGroup', @IDGroup OUTPUT
		
		INSERT INTO MainRetailDB..TabGroup(IDGroup,Name)
		Values
		(
		@IDGroup,
		@GroupName
		)
	END
	FETCH NEXT FROM Group_Cursor INTO
		@GroupName
		
		
		
END
CLOSE Group_Cursor
DEALLOCATE Group_Cursor

-------------------------------------------------------------------------
--Insert ModelGroups
-------------------------------------------------------------------------
PRINT 'Start Update ModelGroups.'
DECLARE ModelGroup_Cursor CURSOR FOR
	SELECT DISTINCT
		Department, Category
	FROM
		MRCatalogDB..Products p
OPEN ModelGroup_Cursor

FETCH NEXT FROM ModelGroup_Cursor INTO
	@GroupName,
	@ModelGroupName
WHILE
@@FETCH_STATUS=0
BEGIN
	print ''
	print @GroupName 
	print @ModelGroupName
	SELECT @IDGroup = (SELECT IDGroup FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	IF  NOT EXISTS( 
		SELECT IDModelGroup FROM MainRetailDb..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
	BEGIN
		EXEC sp_Sis_GetNextCode'ModelGroup.IDModelGroup', @IDModelGroup OUTPUT
		
		SET @IDGroup = (SELECT IDGroup FROM mainRetailDB..TabGroup WHERE Name = @GroupName)		
		INSERT INTO MainRetailDb..ModelGroup(IDModelGroup, ModelGroup, IDGroup)
		VALUES
		(
		@IDModelGroup,
		@ModelGroupName,
		@IDGroup
		)
	END
	FETCH NEXT FROM ModelGroup_Cursor INTO
		@GroupName,
		@ModelGroupName
END
CLOSE ModelGroup_Cursor
DEALLOCATE ModelGroup_Cursor


----------------------------------------------------------------------
--Insert ModelSubGroups
----------------------------------------------------------------------
PRINT 'Start Update ModelSubGroups.'
DECLARE ModelSubGroup_Cursor CURSOR FOR
	SELECT DISTINCT
		Department, Category, SubCategory
	FROM
		MRCatalogDB..Products p
OPEN ModelSubGroup_Cursor
FETCH NEXT FROM ModelSubGroup_Cursor INTO
	@GroupName,
	@ModelGroupName,
	@ModelSubGroupName

WHILE
@@FETCH_STATUS=0
BEGIN
	print ''
	print @GroupName
	print @ModelGroupName
	print @ModelSubGroupName
	SELECT @IDGroup = (SELECT IDGroup FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	SELECT @IDModelGroup = (SELECT IDModelGroup FROM MainRetailDB..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
	IF NOT EXISTS(
	SELECT IDModelSubGroup FROM MainRetailDB..ModelSubGroup WHERE ModelSubGroup = @ModelSubGroupName AND IDModelGroup = @IDModelGroup)
	BEGIN
		EXEC sp_Sis_GetNextCode'ModelSubGroup.IDModelSubGroup', @IDModelSubGroup OUTPUT
			
		SET @IDModelGroup = (SELECT IDModelGroup FROM MainRetailDB..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
		INSERT INTO MainRetailDB..ModelSubGroup(IDModelSubGroup, ModelSubGroup, IDModelGroup)
		VALUES
		(
		@IDModelSubGroup,
		@ModelSubGroupName,
		@IDModelGroup
		)
	END
	FETCH NEXT FROM ModelSubGroup_Cursor INTO
		@GroupName,
		@ModelGroupName,
		@ModelSubGroupName
END	
CLOSE ModelSubGroup_Cursor
DEALLOCATE ModelSubGroup_Cursor