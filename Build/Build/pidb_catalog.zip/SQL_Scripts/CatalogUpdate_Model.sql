use MainRetailDB

DECLARE @Barcode varchar(15)
DECLARE @Model varchar(25)
DECLARE @IDModel int

---------------------------------------------------------------
--Update Model table with catalog information
---------------------------------------------------------------
DECLARE ModelUpdate_Cursor Cursor FOR
	SELECT
		distinct(UPC)
	FROM
		MRCatalogDB..products p
		JOIN MainRetailDB..barcode b on b.idbarcode = p.upc
	WHERE
		UPC <> ''
		and b.BarcodeOrder = 1
	order by UPC

--select t1.idbarcode, t2.idmodel, t2.model from barcode as t1, model as t2 where t1.idbarcode like '715764112%' and t1.idmodel = t2.idmodel order by t1.idbarcode

OPEN ModelUpdate_Cursor 	
 
FETCH NEXT FROM ModelUpdate_Cursor INTO
	@Barcode

WHILE 
@@FETCH_STATUS = 0
/*Update model information*/
BEGIN	
	print @Barcode
	SELECT 
		@IDModel =   IDModel
	FROM 
		MainRetailDB..Barcode
	WHERE 
		IDBarcode = @Barcode
	print @IDModel

	SELECT 
		@Model = sku
	FROM
		MRCatalogDB..products
	WHERE
		UPC = @Barcode
	print @Model

	UPDATE 
		MainRetailDB..Model 
	SET 
		Model = @Model
	WHERE
		IDModel = @IDModel

	FETCH NEXT FROM ModelUpdate_Cursor INTO
		@Barcode
END

CLOSE ModelUpdate_Cursor
DEALLOCATE ModelUpdate_Cursor
