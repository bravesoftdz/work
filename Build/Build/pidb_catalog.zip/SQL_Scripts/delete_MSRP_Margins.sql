select * from tabgroup
select * from modelgroup
select * from modelsubgroup

update tabgroup set IDMSRPMargemTable = NULL
update modelgroup set IDMSRPMargemTable = NULL
update modelsubgroup set IDMSRPMargemTable = NULL