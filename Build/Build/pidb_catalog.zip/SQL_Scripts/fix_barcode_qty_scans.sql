-- Print out items being reset to log file
select m.model, m.description, i.storeid, i.qty from model m join inventorymov i on m.idmodel = i.modelid where qty > 100000 or qty < -100000 order by i.storeid, i.qty

-- Change all of these to 0
update inventorymov set qty = 0 where qty > 100000 or qty < -100000

-- Reset inventory values
EXEC sp_UpdateSystemQty
