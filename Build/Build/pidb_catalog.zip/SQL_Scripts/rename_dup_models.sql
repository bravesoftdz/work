--Verificar modelo duplicado
SELECT I1.Model
FROM Model I1
JOIN Model I2 ON (I1.Model = I2.Model)
GROUP BY I1.Model
HAVING Count(I1.Model) > 1

--Atualizar modelos grade
UPDATE Model
SET Desativado = 1
WHERE IDModelParent IN
(
SELECT IDModelParent FROM Model
WHERE IDModelParent IS NOT NULL
AND IDModelParent NOT IN (SELECT IDModel From Model)
AND TotQtyOnHand = 0 AND Desativado = 0
GROUP BY IDModelParent
)

--Atualiza modelos duplicados
CREATE TABLE #DuplicatedItems
(
IDModel Int,
Model varchar(30)
)

INSERT #DuplicatedItems
(
IDModel,
Model
)

SELECT
M.IDModel,
M.Model
FROM
Model M
WHERE 
M.Model IN (SELECT I1.Model FROM Model I1 JOIN Model I2 ON (I1.Model = I2.Model) GROUP BY I1.Model
HAVING Count(I1.Model) > 1)

DECLARE @Model varchar(30)
DECLARE @ModelOld varchar(30)
DECLARE @IDModel int
DECLARE @Count int

--Verifica modelos na lixeira
SET @Count = 0

DECLARE DeletedModel_Cursor CURSOR FOR
SELECT 
M.IDModel,
M.Model
FROM 
#DuplicatedItems M

OPEN DeletedModel_Cursor

FETCH NEXT FROM DeletedModel_Cursor INTO @IDModel, @Model

WHILE @@FETCH_STATUS = 0
BEGIN

SET @ModelOld = @Model
SET @Count = @Count + 1

UPDATE Model 
SET Model = Model + '.dup.' + CAST(@Count as varchar)
WHERE IDModel = @IDModel AND Desativado = 1

FETCH NEXT FROM DeletedModel_Cursor INTO @IDModel, @Model

IF @ModelOld <> @Model
SET @Count = 0
END

CLOSE DeletedModel_Cursor
DEALLOCATE DeletedModel_Cursor


--Verifica modelos ativos
SET @Count = 0

DECLARE DeletedModel2_Cursor CURSOR FOR
SELECT 
M.IDModel,
M.Model
FROM 
#DuplicatedItems M

OPEN DeletedModel2_Cursor

FETCH NEXT FROM DeletedModel2_Cursor INTO @IDModel, @Model

WHILE @@FETCH_STATUS = 0
BEGIN

SET @ModelOld = @Model
SET @Count = @Count + 1

UPDATE Model 
SET Model = Model + '.dup.' + CAST(@Count as varchar)
WHERE IDModel = @IDModel

FETCH NEXT FROM DeletedModel2_Cursor INTO @IDModel, @Model

IF @ModelOld <> @Model
SET @Count = 0
END

CLOSE DeletedModel2_Cursor
DEALLOCATE DeletedModel2_Cursor


DROP TABLE #DuplicatedItems
