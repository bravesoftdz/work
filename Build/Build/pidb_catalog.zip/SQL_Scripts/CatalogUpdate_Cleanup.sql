update ModelSubGroup set Desativado = 1

update ModelSubGroup set Desativado = 0 where IDModelSubGroup in (select IDModelSubGroup from model where desativado = 0)

update ModelGroup set Desativado = 1

update ModelGroup set Desativado = 0 where IDModelGroup in (select IDModelGroup from Model where Desativado = 0)

update TabGroup set Desativado = 1

update TabGroup set Desativado = 0 where IDGroup in (select GroupID from Model where Desativado = 0)
