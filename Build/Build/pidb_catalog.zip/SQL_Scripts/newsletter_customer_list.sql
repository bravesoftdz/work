use MainRetailDB
go

select Pessoa, PessoaFirstName, PessoaLastName, Email, CreationDate from pessoa 
where Email like '%@%'
order by Email