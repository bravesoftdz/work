DECLARE @IDInventory int
DECLARE @IDModel Int
DECLARE @IDStore int

DECLARE Store_Cursor CURSOR FOR
SELECT
	IDStore
FROM 
	Store
WHERE 
	IDStore <> 0

OPEN Store_Cursor

FETCH NEXT FROM Store_Cursor INTO
	@IDStore

WHILE 
@@FETCH_STATUS = 0
BEGIN

	DECLARE Inventory_Cursor CURSOR FOR

	SELECT 
		IDModel
	FROM
		Model
	WHERE
		IDModel NOT IN (SELECT ModelID FROM Inventory WHERE StoreID = @IDStore)

	OPEN Inventory_Cursor

	FETCH NEXT FROM Inventory_Cursor INTO 
		@IDModel

	WHILE
	@@FETCH_STATUS = 0
	BEGIN

	EXEC sp_Sis_GetNextCode'Inventory.IDInventory', @IDInventory OUTPUT
	INSERT INTO Inventory(IDInventory, ModelID, StoreID)
	VALUES
	(
	@IDInventory,
	@IDModel,
	@IDStore
	)

	FETCH NEXT FROM Inventory_Cursor INTO
	@IDModel

	END

	CLOSE Inventory_CUrsor
	DEALLOCATE Inventory_Cursor

	FETCH NEXT FROM Store_Cursor INTO
		@IDStore
END

CLOSE Store_Cursor
DEALLOCATE Store_Cursor