USE MainRetailDB

DECLARE @Barcode varchar(15)
DECLARE @Model varchar(25)
DECLARE @IDModel int
DECLARE @VendorCode varchar(50)
DECLARE @Vendor varchar(50)
DECLARE @MinQty int
DECLARE @CaseQty int
DECLARE @Cost money
DECLARE @IDPessoa int
DECLARE @IDVendorModelCode int
DECLARE @VendorOrder int
DECLARE @Inactive bit
DECLARE @Last_Modified smalldatetime

------------------------------------------------------------------------------------
--Clear out NULL Date costs
------------------------------------------------------------------------------------
--delete from inv_modelvendor where costlastchange is NULL
--go
update inv_modelvendor set costlastchange = '2000-01-01 00:00:00.000' where costlastchange is NULL

------------------------------------------------------------------------------------
--Update vendor information with catalog information
------------------------------------------------------------------------------------
PRINT 'Start update vendor information with catalog information section.'
DECLARE VendorUpdate_Cursor Cursor FOR
	SELECT
		M.IDModel,
		P.UPC,
		P.sku,
		V.IDVendorMR,
		CONVERT(int, PV.vmin_qty) / pv.vsell_pkg as minqty,
		CASE pv.vsell_pkg WHEN 1 THEN 0 ELSE pv.vsell_pkg END,
		PV.vinactive,
		PV.vcost,
		PV.last_modified
	FROM
		MRCatalogDB..products P
		JOIN MRCatalogDB..products_vendors PV ON P.sku = PV.sku
		JOIN MRCatalogDB..vendors V ON PV.IDVendor = V.IDVendor
		JOIN MainRetailDB..Model M on M.Model = P.Sku
	WHERE
		V.IDVendorMR IS NOT NULL
		and V.IDVendorMR != 110
	ORDER BY M.Model
OPEN VendorUpdate_Cursor

FETCH NEXT FROM VendorUpdate_Cursor INTO
	@IDModel,
	@Barcode,
	@Model,
	@Vendor,
	@MinQty,
	@CaseQty,
	@Inactive,
	@Cost,
	@Last_Modified

WHILE
@@FETCH_STATUS = 0
BEGIN
--	SELECT 
--		@IDModel = IDModel
--	FROM
--		MainRetailDB..Model
--	WHERE
--		IDBarcode = @Barcode
	
	IF @Inactive = 1
	BEGIN
		insert into MRCatalogDB..Delete_VendorLog (IDModel, Barcode, Model, Vendor, MinQty, CaseQty, Inactive, Cost)
		values (@IDModel, @Barcode, @Model, @Vendor, @MinQty, @CaseQty,	@Inactive, @Cost)

		DELETE FROM 
			Inv_ModelVendor
		WHERE
			IDModel = @IDModel
			AND IDPessoa = @Vendor
		DELETE FROM
			VendorModelCode
		WHERE
			IDModel = @IDModel
			AND IDPessoa = @Vendor

	PRINT 'Delete ' + convert(varchar, @idmodel) + ',' + convert(varchar, @vendor)
	END
	ELSE
	BEGIN
		UPDATE 
			MainRetailDB..Inv_ModelVendor 
		SET 
			MinQtyPO = @MinQty, CaseQty = @CaseQty, VendorCost = @cost, CostLastChange = @Last_Modified
		WHERE
			IDPessoa = @Vendor AND IDModel = @IDModel AND CostLastChange < @Last_Modified

	PRINT @Model + ' ' + @Vendor + ' ' + convert(varchar, @cost) 
	--PRINT @Last_Modified
	END

	FETCH NEXT FROM VendorUpdate_Cursor INTO
		@IDModel,
		@Barcode,
		@Model,
		@Vendor,
		@MinQty,
		@CaseQty,
		@Inactive,
		@Cost,
		@Last_Modified

END
CLOSE VendorUpdate_Cursor
DEALLOCATE VendorUpdate_Cursor

-------------------------------------------
--Inserts vendors for the items
-------------------------------------------
PRINT 'Start insert vendors for the items section.'
DECLARE VendorInsert_Cursor Cursor FOR
	SELECT
		P.sku,
		V.IDVendorMR,
		CONVERT(int, PV.vmin_qty) / pv.vsell_pkg as minqty,
		CASE pv.vsell_pkg WHEN 1 THEN 0 ELSE pv.vsell_pkg END,
		pv.vcost,
		PV.last_modified
	FROM
		MRCatalogDB..products P
		JOIN MRCatalogDB..products_vendors PV ON P.sku = PV.sku
		JOIN MRCatalogDB..vendors V ON PV.IDVendor = V.IDVendor
		JOIN MainRetailDB..Model M on p.sku = m.Model
	WHERE
		V.IDVendorMR IS NOT NULL
		and V.IDVendorMR != 110
		AND PV.Vinactive = 0

	ORDER BY P.Sku
OPEN VendorInsert_Cursor

FETCH NEXT FROM VendorInsert_Cursor INTO
	@Model,
	@Vendor,
	@MinQty,
	@CaseQty,
	@cost,
	@Last_Modified

WHILE
@@FETCH_STATUS = 0
BEGIN
	/*get mr id
	SELECT
		@IDPessoa = IDPessoa
	FROM
		MainRetailDB..Pessoa
	WHERE
		Pessoa = @Vendor AND
		IDTipoPessoa = 2 AND
		Desativado = 0
	*/ --using idvendormr now

	SELECT 
		@IDModel = IDModel
	FROM
		MainRetailDB..Model
	WHERE
		Model = @Model

	IF NOT EXISTS 
		(SELECT IDModel FROM MainRetailDb..Inv_ModelVendor WHERE IDModel = @IDModel)
	BEGIN
	INSERT INTO MainRetailDb..Inv_ModelVendor(IDModel, IDPessoa, VendorOrder, MinQtyPO, CaseQty, VendorCost, CostLastChange)
	SELECT
		@IDModel,
		@Vendor,
		1,
		@MinQty,
		@CaseQty,
		@Cost,
		@Last_Modified
	insert into MRCatalogDB..Insert_Inv_ModelVendorLog (IDModel, Vendor, MinQty, CaseQty, Cost, Mod_Time)
	values (@IDModel, @Vendor, @MinQty, @CaseQty, @Cost, @Last_Modified)
	END

	ELSE IF NOT EXISTS
		(SELECT IDModel FROM MainRetailDb..Inv_ModelVendor WHERE IDModel = @IDModel AND IDPessoa = @Vendor)
	BEGIN
	INSERT INTO MainRetailDb..Inv_ModelVendor(IDModel, IDPessoa, VendorOrder, MinQtyPO, CaseQty, VendorCost, CostLastChange)
	SELECT
		@IDModel,
		@Vendor,
		Max(VendorOrder) + 1,
		@MinQty,
		@CaseQty,
		@Cost,
		@Last_Modified
	FROM
		MainRetailDb..Inv_ModelVendor
	WHERE
		IDModel = @IDModel
	END

	PRINT @Model
	PRINT @Vendor
	PRINT @MinQty
	PRINT @CaseQty
	PRINT @Last_Modified
	PRINT convert(varchar, @cost)

	FETCH NEXT FROM VendorInsert_Cursor INTO
		@Model,
		@Vendor,
		@MinQty,
		@CaseQty,
		@cost,
		@Last_Modified
END

CLOSE VendorInsert_Cursor
DEALLOCATE VendorInsert_Cursor

---------------------------------------------
--Insert vendorcodes for all items
---------------------------------------------
PRINT 'Start insert vendorcodes for all items section.'
DECLARE VendorCode_Cursor Cursor FOR
	SELECT
		P.sku,
		V.IDVendorMR,
		PV.vsku
	FROM
		MRCatalogDB..products P
		JOIN MRCatalogDB..products_vendors PV ON P.sku = PV.sku
		JOIN MRCatalogDB..vendors V ON PV.IDVendor = V.IDVendor
		JOIN MainRetailDB..Model M on p.sku = M.Model
	WHERE
		V.IDVendorMR IS NOT NULL
		and V.IDVendorMR != 110
		AND PV.Vinactive = 0
OPEN VendorCode_Cursor

FETCH NEXT FROM VendorCode_Cursor INTO
	@Model,
	@Vendor,
	@VendorCode

WHILE
@@FETCH_STATUS = 0
BEGIN
	SELECT 
		@IDModel = IDModel
	FROM
		MainRetailDB..Model
	WHERE
		Model = @Model

	IF NOT EXISTS 
		(SELECT IDModel FROM MainRetailDB..VendorModelCode WHERE IDModel = @IDModel AND IDPessoa = @Vendor)
		BEGIN
			EXEC MainRetailDB..sp_Sis_GetNextCode 'VendorModelCode.IDVendorModelCode', @IDVendorModelCode OUTPUT
			INSERT INTO MainRetailDB..VendorModelCode(IDVendorModelCode, IDModel, IDPessoa, VendorCode)
			VALUES
			(
				@IDVendorModelCode,
				@IDModel,
				@Vendor,
				@VendorCode
			)
		INSERT INTO MRCatalogDb..Insert_VendorModelCode (IDVendorModelCode,IDModel,Vendor,VendorCode)
		values (@IDVendorModelCode,@IDModel,@Vendor,@VendorCode)
		END
	ELSE
		UPDATE MainRetailDB..VendorModelCode SET VendorCode = @VendorCode WHERE IDModel  = @IDModel AND IDPessoa = @Vendor
		INSERT INTO MRCatalogDb..Insert_VendorModelCode (IDVendorModelCode,IDModel,Vendor,VendorCode)
		values(@IDVendorModelCode,@IDModel,@Vendor,@VendorCode)
	Print @Model
	Print @Vendor
	Print @VendorCode

	FETCH NEXT FROM VendorCode_Cursor INTO
		@Model,
		@Vendor,
		@VendorCode
		
END

CLOSE VendorCode_Cursor
DEALLOCATE VendorCode_Cursor

-------------------------------------------
--Remove any PIDB codes
-------------------------------------------
PRINT 'Start remove PIDB vendor.'
DELETE FROM 
	Inv_ModelVendor
WHERE
	IDPessoa = (select idvendormr from MRCatalogDB..vendors where idvendor = 110)
DELETE FROM
	VendorModelCode
WHERE
	IDPessoa = (select idvendormr from MRCatalogDB..vendors where idvendor = 110)


---------------------------------------------------------------------------------------------------
--reset vendor orders in case some were deleted in vendor update section
---------------------------------------------------------------------------------------------------
PRINT 'Start reset orders section.'
DECLARE VendorOrder_Cursor CURSOR FOR
	SELECT
		DISTINCT IDModel
	FROM
		MainRetailDB..Inv_ModelVendor
OPEN VendorOrder_Cursor

FETCH NEXT FROM VendorOrder_Cursor INTO
	@IDModel

WHILE
@@FETCH_STATUS = 0
BEGIN
	DECLARE Update_Cursor Cursor FOR
		SELECT
			IDPessoa
		FROM
			MainRetailDB..Inv_ModelVendor
		WHERE
			IDModel = @IDModel
		ORDER BY
			VendorOrder ASC
	OPEN Update_Cursor
	
	FETCH NEXT FROM Update_Cursor INTO
		@IDPessoa
	SET @VendorOrder = 0
	WHILE
	@@FETCH_STATUS = 0
	BEGIN
		SELECT @VendorOrder = @VendorOrder + 1
		UPDATE
			MainRetailDB..Inv_ModelVendor
		SET
			VendorOrder  = @VendorOrder
		WHERE
			IDModel = @IDModel AND IDPessoa = @IDPessoa
		
		FETCH NEXT FROM Update_Cursor INTO
			@IDPessoa
	END
	CLOSE Update_Cursor
	DEALLOCATE Update_Cursor

	Print @IDModel

	FETCH NEXT FROM VendorOrder_Cursor INTO
		@IDModel
END
CLOSE VendorOrder_Cursor
DEALLOCATE VendorOrder_Cursor

-------------------------------------------------------------------------------------
--Assign vendor by cost
-------------------------------------------------------------------------------------
PRINT 'Start assign vendor by cost section.'
DECLARE CostOrder_Cursor CURSOR FOR
	SELECT
		Model
	FROM
		MainRetailDB..Model M
		--JOIN MRCatalogDB..Products P ON M.Model = P.SKU
		JOIN MainRetailDB..Inv_ModelVendor I ON M.IDModel = I.IDModel
		--JOIN MRCatalogDB..Vendors V ON I.IDPessoa = V.IDVendorMR
	WHERE
		I.VendorOrder = 1
OPEN CostOrder_Cursor

FETCH NEXT FROM CostOrder_Cursor INTO
	@Model

WHILE
@@FETCH_STATUS = 0
BEGIN
	DECLARE VendorOrder_Cursor CURSOR FOR
		SELECT
			I.IDModel,
			I.IDPessoa,
			IsNull(I.VendorCost, 100000) as cost			
		FROM
			MainRetailDb..Inv_ModelVendor i
			JOIN MainRetailDB..Model m ON m.idmodel = i.idmodel
		WHERE
			m.Model = @Model 
		ORDER BY
			 cost
	OPEN VendorOrder_Cursor
	FETCH NEXT FROM VendorOrder_Cursor INTO
		@IDModel,
		@IDPessoa,
		@Cost
	
	SELECT @VendorOrder = 0
	WHILE
	@@FETCH_STATUS = 0
	BEGIN
		SELECT @VendorOrder = @VendorOrder + 1
		
		UPDATE
			MainRetailDB..Inv_ModelVendor
		SET
			VendorOrder = @VendorOrder
		WHERE
			IDModel = @IDModel AND IDPessoa = @IDPessoa
	
		FETCH NEXT FROM VendorOrder_Cursor INTO
		@IDModel,
		@IDPessoa,
		@Cost
	END
	CLOSE VendorOrder_Cursor
	DEALLOCATE VendorOrder_Cursor

	Print @Model
	
	FETCH NEXT FROM CostOrder_Cursor INTO
	@Model
END
CLOSE CostOrder_Cursor
DEALLOCATE CostOrder_Cursor

--------------------------------------------------------
--Set cost to primary vendor cost
--------------------------------------------------------
PRINT 'Start set cost to primary vendor section.'
	UPDATE
		M 
	SET 
		M.VendorCost = I.VendorCost 
	FROM 
		Model M 
		JOIN Inv_ModelVendor I ON M.IDModel  = I.IDModel 
	WHERE 	
		M.desativado = 0 AND I.VendorOrder = 1 AND I.VendorCost IS NOT NULL
		AND I.VendorCost <> .0000 AND M.VendorCost = .0000 AND I.CaseQty = 0.0000
-- Need to add in for items with CaseQty
