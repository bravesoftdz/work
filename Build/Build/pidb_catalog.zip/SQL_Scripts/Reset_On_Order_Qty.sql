-- Get rid of store 0 entrys as they are invalid
--delete from POItemRequest where idpreinventorymov in 
--(select idpreinventorymov from preinventorymov where storeid = 0)
--delete from preinventorymov where storeid = 0
--delete from inventory where storeid = 0

-- Reset preinventorymov
update 
 pre
set
 pre.qtyrealmov = pre.qty
from
 preinventorymov pre
 join PO on pre.documentid = po.idpo and pre.inventmovtypeid = 2
where
 po.aberto = 0
 and
 pre.qtyrealmov <> pre.qty

-- Reset inventory to 0
update i set i.qtyonorder = 0 from inventory i

-- Update Inventory
update 
 i 
set 
 i.qtyonorder = t.qtyonorder
from
 inventory i
 join (
  select
   modelid,
   storeid,
   sum(qty-qtyrealmov) as qtyonorder
  from
   preinventorymov pre
   join PO on pre.documentid = po.idpo and pre.inventmovtypeid = 2
  where
   po.aberto = 1
  group by
   modelid, storeid
  )t on i.modelid = t.modelid and i.storeid = t.storeid

EXEC sp_UpdateSystemQty
