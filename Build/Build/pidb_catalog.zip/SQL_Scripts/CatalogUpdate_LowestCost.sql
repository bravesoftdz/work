USE MainRetailDB

DECLARE @Barcode varchar(15)
DECLARE @Model varchar(25)
DECLARE @IDModel int
DECLARE @VendorCode varchar(50)
DECLARE @Vendor varchar(50)
DECLARE @MinQty int
DECLARE @CaseQty int
DECLARE @Cost money
DECLARE @IDPessoa int
DECLARE @IDVendorModelCode int
DECLARE @VendorOrder int
DECLARE @Inactive bit
DECLARE @Last_Modified smalldatetime

-------------------------------------------------------------------------------------
--Assign vendor by cost
-------------------------------------------------------------------------------------
PRINT 'Start assign vendor by cost section.'
DECLARE CostOrder_Cursor CURSOR FOR
	SELECT
		distinct(Model)
	FROM
		MainRetailDB..Model M
	--	JOIN MRCatalogDB..Products P ON M.Model = P.SKU
	--	JOIN MainRetailDB..Inv_ModelVendor I ON M.IDModel = I.IDModel
	--	JOIN MRCatalogDB..Vendors V ON I.IDPessoa = V.IDVendorMR
	--WHERE
	--	I.VendorOrder = 1
OPEN CostOrder_Cursor

FETCH NEXT FROM CostOrder_Cursor INTO
	@Model

WHILE
@@FETCH_STATUS = 0
BEGIN
	DECLARE VendorOrder_Cursor CURSOR FOR
		SELECT
			I.IDModel,
			I.IDPessoa,
			IsNull(I.VendorCost, 100000) as cost			
		FROM
			MainRetailDB..Inv_ModelVendor i
			JOIN MainRetailDB..Model m ON m.idmodel = i.idmodel
		WHERE
			m.Model = @Model 
		ORDER BY
			 cost
	OPEN VendorOrder_Cursor
	FETCH NEXT FROM VendorOrder_Cursor INTO
		@IDModel,
		@IDPessoa,
		@Cost
	
	SELECT @VendorOrder = 0
	WHILE
	@@FETCH_STATUS = 0
	BEGIN
		SELECT @VendorOrder = @VendorOrder + 1
		
		UPDATE
			MainRetailDB..Inv_ModelVendor
		SET
			VendorOrder = @VendorOrder
		WHERE
			IDModel = @IDModel AND IDPessoa = @IDPessoa
	
		FETCH NEXT FROM VendorOrder_Cursor INTO
		@IDModel,
		@IDPessoa,
		@Cost
	END
	CLOSE VendorOrder_Cursor
	DEALLOCATE VendorOrder_Cursor

	Print @Model
	
	FETCH NEXT FROM CostOrder_Cursor INTO
	@Model
END
CLOSE CostOrder_Cursor
DEALLOCATE CostOrder_Cursor