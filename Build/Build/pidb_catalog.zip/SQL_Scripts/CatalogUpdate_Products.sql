use MainRetailDB

  DECLARE @Image varchar(50)
  DECLARE @Description varchar(100)
  DECLARE @Model varchar(25)
  DECLARE @IDModel int
  DECLARE @MSRP money
  DECLARE @IDPessoa int
  DECLARE @IDGroup int
  DECLARE @IDModelGroup int
  DECLARE @IDModelSubGroup int
  DECLARE @Department varchar(50)
  DECLARE @Category varchar(100)
  DECLARE @SubCategory varchar(100)
  DECLARE @Pessoa varchar(50)
  DECLARE @GroupName varchar(50)
  DECLARE @ModelGroupName varchar(50)
  DECLARE @ModelSubGroupName varchar(50)

---------------------------------------------------------------
--Update Model table with catalog information
---------------------------------------------------------------
PRINT 'Start Update Model table with catalog information.'
DECLARE ModelUpdate_Cursor Cursor FOR
	SELECT
		SKU
	FROM
		MRCatalogDB..products p
		JOIN MainRetailDB..model m on m.Model = p.sku
        WHERE
                m.NoUpdateCatalogs <> 1
OPEN ModelUpdate_Cursor
 
FETCH NEXT FROM ModelUpdate_Cursor INTO
	@Model

WHILE 
@@FETCH_STATUS = 0
/*Update model information*/
BEGIN	
	SELECT 
		@IDModel =   IDModel
	FROM 
		MainRetailDB..Model
	WHERE 
		Model = @Model

	SELECT 
		@Description = title,
--		@Model = sku,
		@MSRP = retail_price,
		@Image = image
	FROM
		MRCatalogDB..products
	WHERE
		SKU = @Model

	UPDATE 
		MainRetailDB..Model 
	SET 
		Description = @Description, 
		SuggRetail = @MSRP,
		LargeImage = 'C:\Pinogy\mr_images\' + @Image
	WHERE
		IDModel = @IDModel

	PRINT @IDModel

	FETCH NEXT FROM ModelUpdate_Cursor INTO
		@Model
END

CLOSE ModelUpdate_Cursor
DEALLOCATE ModelUpdate_Cursor

----------------------------------------------------------------
--Insert tabgroups
----------------------------------------------------------------
Print ''
PRINT 'Start Insert tabgroups.'
DECLARE Group_Cursor Cursor FOR
	SELECT DISTINCT
		Department
	FROM
		MRCatalogDB..Products p
		JOIN MainRetailDB..model m on m.Model = p.sku
	WHERE
		p.department IS NOT NULL and p.department <> ''                

OPEN Group_Cursor

FETCH NEXT FROM Group_Cursor INTO
	@GroupName
	
WHILE
@@FETCH_STATUS=0
BEGIN
	IF NOT EXISTS(
		SELECT distinct(IDGroup) FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	BEGIN
		EXEC sp_Sis_GetNextCode'TabGroup.IDGroup', @IDGroup OUTPUT
		
		INSERT INTO MainRetailDB..TabGroup(IDGroup,Name)
		Values
		(
		@IDGroup,
		@GroupName
		)
	END

	PRINT @GroupName

	FETCH NEXT FROM Group_Cursor INTO
		@GroupName

END
CLOSE Group_Cursor
DEALLOCATE Group_Cursor

-------------------------------------------------------------------------
--Insert ModelGroups
-------------------------------------------------------------------------
Print ''
PRINT 'Start Insert ModelGroups.'
DECLARE ModelGroup_Cursor CURSOR FOR
	SELECT DISTINCT
		Department, Category
	FROM
		MRCatalogDB..Products p
		JOIN MainRetailDB..model m on m.Model = p.sku
	WHERE
		p.category IS NOT NULL and p.category <> ''

OPEN ModelGroup_Cursor

FETCH NEXT FROM ModelGroup_Cursor INTO
	@GroupName,
	@ModelGroupName
WHILE
@@FETCH_STATUS=0
BEGIN
	SELECT @IDGroup = (SELECT IDGroup FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	IF  NOT EXISTS( 
		SELECT IDModelGroup FROM MainRetailDb..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
	BEGIN
		EXEC sp_Sis_GetNextCode'ModelGroup.IDModelGroup', @IDModelGroup OUTPUT
		
		SET @IDGroup = (SELECT IDGroup FROM mainRetailDB..TabGroup WHERE Name = @GroupName)		
		INSERT INTO MainRetailDb..ModelGroup(IDModelGroup, ModelGroup, IDGroup)
		VALUES
		(
		@IDModelGroup,
		@ModelGroupName,
		@IDGroup
		)
	END

	Print @GroupName + ' ' + @ModelGroupName

	FETCH NEXT FROM ModelGroup_Cursor INTO
		@GroupName,
		@ModelGroupName
END
CLOSE ModelGroup_Cursor
DEALLOCATE ModelGroup_Cursor


----------------------------------------------------------------------
--Insert ModelSubGroups
----------------------------------------------------------------------
Print ''
Print 'Start insert ModelSubGroups'
DECLARE ModelSubGroup_Cursor CURSOR FOR
	SELECT DISTINCT
		Department, Category, SubCategory
	FROM
		MRCatalogDB..Products p
		JOIN MainRetailDB..model m on m.Model = p.sku
	WHERE
		SubCategory <> '' AND SubCategory IS NOT NULL

OPEN ModelSubGroup_Cursor
FETCH NEXT FROM ModelSubGroup_Cursor INTO
	@GroupName,
	@ModelGroupName,
	@ModelSubGroupName

WHILE
@@FETCH_STATUS=0
BEGIN
	SELECT @IDGroup = (SELECT IDGroup FROM MainRetailDB..TabGroup WHERE Name = @GroupName)
	SELECT @IDModelGroup = (SELECT IDModelGroup FROM MainRetailDB..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
	IF NOT EXISTS(
	SELECT IDModelSubGroup FROM MainRetailDB..ModelSubGroup WHERE ModelSubGroup = @ModelSubGroupName AND IDModelGroup = @IDModelGroup)
	BEGIN
		EXEC sp_Sis_GetNextCode'ModelSubGroup.IDModelSubGroup', @IDModelSubGroup OUTPUT
			
		SET @IDModelGroup = (SELECT IDModelGroup FROM MainRetailDB..ModelGroup WHERE ModelGroup = @ModelGroupName AND IDGroup = @IDGroup)
		INSERT INTO MainRetailDB..ModelSubGroup(IDModelSubGroup, ModelSubGroup, IDModelGroup)
		VALUES
		(
		@IDModelSubGroup,
		@ModelSubGroupName,
		@IDModelGroup
		)
	END

	Print @GroupName + ' ' + @ModelGroupName + ' ' + @ModelSubGroupName

	FETCH NEXT FROM ModelSubGroup_Cursor INTO
		@GroupName,
		@ModelGroupName,
		@ModelSubGroupName
END	
CLOSE ModelSubGroup_Cursor
DEALLOCATE ModelSubGroup_Cursor
----------------------------------------------------------------------------------------------
--Set Category Sub Category and Group
----------------------------------------------------------------------------------------------
PRINT ''
Print 'Start Set Category, SubCategory, and Group.'
DECLARE Category_Cursor Cursor FOR
	SELECT
		P.SKU,
		P.Department,
		P.Category,
		P.SubCategory
	FROM
		MRCatalogDB..products P
	WHERE
		P.sku <> '' AND P.sku IN (SELECT model FROM MainRetailDB..Model where NoUpdateCatalogs <> 1) 
		AND p.department <> 'Uncategorized'
	Order by P.SKU

OPEN Category_Cursor

FETCH NEXT FROM Category_Cursor INTO
	@Model,
	@Department,
	@Category,
	@subcategory

WHILE
@@FETCH_STATUS = 0
BEGIN
	SELECT @IDGroup = NULL
	SELECT @IDModelGroup = NULL
	SELECT @IDModelSubGroup = NULL
	IF @Department IS NOT NULL AND @Department <> ''
	BEGIN
		SELECT @IDGroup = IDGroup FROM MainRetailDB..TabGroup WHERE Name = @Department
	
		IF @Category IS NOT NULL AND @Category <> ''
		BEGIN
			SELECT @IDModelGroup = IDModelGroup FROM MainRetailDB..ModelGroup WHERE ModelGroup = @category AND IDGroup = @IDGroup
		
			IF @subcategory IS NOT NULL AND @subcategory <> ''
				SELECT @IDModelSubGroup = IDModelSubGroup FROM MainRetailDB..ModelSubGroup WHERE ModelSubGroup = @subcategory AND IDModelGroup = @IDModelGroup
		--	ELSE
		--		SELECT @IDModelSubGroup = NULL
		END
	--	ELSE
	--		SELECT @IDModelGroup = NULL
	END
--	ELSE
--		SELECT @IDGroup = NULL

	IF @IDGroup IS NOT NULL AND @IDGroup <> ''
                --UPDATE MainRetailDB..Model set IDModelGroup = NULL, IDModelSubGroup = NULL WHERE Model = @Model
		UPDATE MainRetailDB..Model 
		SET GroupID = @IDGroup, IDModelGroup = @IDModelGroup, IDModelSubGroup = @IDModelSubGroup 
		WHERE Model = @Model

	Print @Model 
	Print @Department + ' ' + @Category + ' ' + @subcategory
	Print @IDGroup + ' ' + @IDModelGroup + ' ' + @IDModelSubGroup

	FETCH NEXT FROM Category_Cursor INTO
		@Model,
		@Department,
		@Category,
		@subcategory
END
CLOSE Category_Cursor
DEALLOCATE Category_Cursor

-------------------------------------------------------------------------------------
--insert all mfg's for catalog items in MR
-------------------------------------------------------------------------------------
Print ''
Print 'Start insert all mfgs for catalog items in MR'
DECLARE mfg_Cursor CURSOR FOR
SELECT DISTINCT 
	mfg
FROM
	MRCatalogDB..Products
WHERE
	mfg NOT IN (SELECT Pessoa FROM MainRetailDB..Pessoa WHERE IDTipoPessoa = 7)
	AND Sku IN (SELECT Model FROM MainRetailDB..Model)
OPEN mfg_Cursor

FETCH NEXT FROM mfg_CURSOR INTO
	@Pessoa

WHILE
@@FETCH_STATUS = 0
BEGIN
	EXEC MainRetailDB..sp_Sis_GetNextCode 'Pessoa.IDPessoa', @IDPessoa OUTPUT
	INSERT INTO MainRetailDB..Pessoa(IDPessoa, IDTipoPessoa, IDTipoPessoaRoot, IDStore, IDUser, Pessoa, Juridico, Code)
	SELECT
		@IDPessoa,
		7,
		7,
		1,
		1,
		@Pessoa,
		1,
		Max(Code) + 1
	FROM
		MainRetailDB..Pessoa
	WHERE
		IDTipoPessoa = 7

	Print @Pessoa

FETCH NEXT FROM mfg_CURSOR INTO
	@Pessoa
END

CLOSE mfg_CURSOR
DEALLOCATE mfg_CURSOR

----------------------------------------------------------------------------
--Update all catalog models with the correct mfg
----------------------------------------------------------------------------
Print 'Start Update all catalog models with the correct mfg'
DECLARE mfgUpdate_Cursor Cursor FOR
	SELECT
		M.Model
	FROM
		MainRetailDB..Model M
		JOIN MRCatalogDB..Products P ON M.Model = P.Sku
        WHERE
                m.NoUpdateCatalogs <> 1
OPEN mfgUpdate_Cursor

FETCH NEXT FROM mfgUPDATE_CURSOR INTO
	@model

WHILE 
@@FETCH_STATUS = 0
BEGIN
	UPDATE 
		M 
	SET 
		M.IDFabricante = P.IDPessoa
	FROM
		MainRetailDB..Model M
		JOIN MRCatalogDB..Products PR ON M.Model = PR.SKU
		JOIN MainRetailDB..Pessoa P ON P.Pessoa = PR.mfg 
	WHERE
		PR.SKU = @Model AND P.IDTipoPessoa =  7 AND P.Desativado = 0

	PRINT @Model

	FETCH NEXT FROM mfgUPDATE_CURSOR INTO
		@Model
END
CLOSE mfgUPDATE_CURSOR
DEALLOCATE mfgUPDATE_CURSOR