select t1.model from model t1
join Model t2 on (t1.model = t2.model)
group by t1.model
having  count(t1.model) > 1
order by t1.model
