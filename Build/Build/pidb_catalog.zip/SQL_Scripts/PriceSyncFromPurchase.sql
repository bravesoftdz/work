update
	m 
set 
	m.sellingprice = p.newsaleprice, m.vendorcost = p.newcostprice
from 
	model m join pur_purchaseitem p on p.idmodel = m.idmodel
where
	p.idpurchase in (344, 345)
