update model set suggretail = 48.49, DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP39321'
go
update inventory set SellingPrice = 44.49, MinQty = 2, MaxQty = 2 where ModelID = (select idmodel from model where model = 'NPP39321')
go
update model set suggretail = , DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP12323'
go
update inventory set SellingPrice = , MinQty = 1, MaxQty = 1 where ModelID = (select idmodel from model where model = 'NPP12323')
go
update model set suggretail = 23.99, DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP41608'
go
update inventory set SellingPrice = 19.99, MinQty = 1, MaxQty = 2 where ModelID = (select idmodel from model where model = 'NPP41608')
go
update model set suggretail = , DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP12335'
go
update inventory set SellingPrice = , MinQty = 0, MaxQty = 0 where ModelID = (select idmodel from model where model = 'NPP12335')
go
update model set suggretail = , DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP82351'
go
update inventory set SellingPrice = , MinQty = 0, MaxQty = 1 where ModelID = (select idmodel from model where model = 'NPP82351')
go
update model set suggretail = , DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP12333'
go
update inventory set SellingPrice = , MinQty = 1, MaxQty = 1 where ModelID = (select idmodel from model where model = 'NPP12333')
go
update model set suggretail = 48.49, DateLastSellingPrice = '2008-11-11 16:25:04' where model = 'NPP39350'
go
update inventory set SellingPrice = 44.49, MinQty = 2, MaxQty = 2 where ModelID = (select idmodel from model where model = 'NPP39350')
go
